import "./header.css";

export default function Header() {
  return (
    <div className="header">
      <div className="headerTitles">
        <span className="headerTitleSm">React & Node</span>
        <span className="headerTitleLg">BLOG</span>
      </div>
      <img
        className="headerImg"
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkxbogwIukFLRE8Qz_h-AtiPL61vaM06pOyA&usqp=CAU"
        alt=""
      />
    </div>
  );
}
